drop database clr;

create database clr;
use clr;
create table setor(
	codigo int auto_increment primary key,
    descricao varchar(50),
    observacao varchar(200),
    acesso boolean
);
create table funcionario(
	codigo 			int auto_increment primary key,
    cpf				varchar(11),
    rg 				varchar(9),
    nome 			varchar(20),
    cidade	 		varchar(50),
    endereco 		varchar(100),
    uf 				varchar(2),
    nomeuser 		varchar(10),
    senha 			varchar(200),
    email 			varchar(50),
    datanasc 		varchar(10),
    setor	 		int,
    tipo 			boolean,
    telefone 		varchar(11),
    farma 			boolean,
    foreign key (setor) references setor (codigo)
);
create table paciente(
	codigo			int auto_increment primary key,
    cpf 			varchar(11),
    rg 				varchar(9),
    nome 			varchar(20),
    cidade	 		varchar(50),
    endereco 		varchar(100),
    email 			varchar(50),
	telefone 		varchar(11),
    estcivil 		varchar(15),
    datanasc 		varchar(10),
    profissao 		varchar(20),
    cartsus 		varchar(20),
    nummatric 		int,
    datacad 		date,
    nomemae 		varchar(50),
    nomepai 		varchar(50),
    sexo 			varchar(10)
);
create table medicamento(
	codigo   		int auto_increment primary key,
    nomemed 		varchar(50),
    quantidade 		int,
    miligrama 		double,
    acao 			varchar(100)
);
create table tipoatend(
	codigo 			int auto_increment primary key,
    descricao 		varchar(50),
    observacao 		varchar(200)
);
create table medico(
    codigo 			int auto_increment primary key,
    cpf				varchar(11),
    rg 				varchar(9),
    nome 			varchar(20),
    cidade 			varchar(50),
    endereco 		varchar(100),
    uf 				varchar(2),
    nomeuser 		varchar(10),
    senha 			varchar(200),
    email 			varchar(50),
    datanasc 		varchar(10),
    telefone 		varchar(11),
    crm 			varchar(50),
    inicio 			time,
    termino 		time,
    especialidade 	varchar(50)
);
create table chegMed(
	codigo 			int auto_increment primary key,
    medicamento 	int,
    funcionario 	int,
    quantidade 		int, 
    datachegada 	date, 
    horario 		time,
    foreign key (medicamento) references medicamento(codigo),
    foreign key (funcionario) references funcionario(codigo)
);
create table fichaAtend(
	codigo 			int auto_increment primary key,
    funcionario 	int,
    horario 		time,
    dataatend		date,
    tipoatend 		int,
    paciente 		int,
    numeroordem 	int,
    atendmed 		boolean,
    foreign key (funcionario) references funcionario(codigo),
    foreign key (tipoatend) references tipoatend(codigo),
    foreign key (paciente) references paciente(codigo)
);
create table preConsulta(
	codigo   		int auto_increment primary key,
    peso 			double,
    altura 			double,
    idade 			int,
    sistolica		int,
    diastolica		int,
    funcionario 	int,
    medico 			int,
    fichaatend 		int,
    dataPrec		date,
    foreign key (funcionario) references funcionario(codigo),
    foreign key (medico) references medico(codigo),
    foreign key (fichaatend) references fichaAtend(codigo)
);
create table consulta(
	codigo 			int auto_increment primary key,
    preconsulta 	int,
    diagnostico 	varchar(500),
    observacoes 	varchar(500),
    foreign key (preconsulta) references preconsulta(codigo)
);
create table receita(
	codigo 			int auto_increment primary key,
    quantidade 		int, 
    dosagem 		varchar(30),
    consulta 		int,
	foreign key (consulta) references consulta(codigo)
    
);

create table retiradaMed(
	codigo 			int auto_increment primary key,
    funcionario 	int,
    paciente 		int,
    dataret 		date,
    medicamento 	int,
	foreign key (medicamento) references medicamento(codigo),
    foreign key (funcionario) references funcionario(codigo),
	foreign key (paciente) references paciente(codigo)
);
create table exame(
	codigo 			int auto_increment primary key,
    descricao 		varchar(100),
	consulta 		int,
	observacoes 	varchar(500),
	foreign key (consulta) references consulta(codigo)
);
insert into medico (nome, especialidade, crm) values ("espero que de certo", "Brains", "10652655");