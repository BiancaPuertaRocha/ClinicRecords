
package ManterMedico;

import Utilidades.GerenciamentoEntidades;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class ControleMedico {

    EntityManagerFactory fabrica;

    public ControleMedico() {

    }

    public void adicionaMedico(Medico novoMedico) {
        EntityManager gerEntidade;
       
        gerEntidade = GerenciamentoEntidades.criarGerente();

        gerEntidade.getTransaction().begin();

        gerEntidade.persist(novoMedico);

        gerEntidade.getTransaction().commit();

        gerEntidade.close();
    }

    public void alteraMedico(Medico medico) {
        EntityManager gerEntidade;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        gerEntidade.getTransaction().begin();
        gerEntidade.merge(medico);
        gerEntidade.getTransaction().commit();
        gerEntidade.close();
    }

    public void excluiMedico(Medico medico) {
        EntityManager gerEntidade;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        gerEntidade.getTransaction().begin();
        medico = gerEntidade.find(Medico.class, medico.getCodigo());
        gerEntidade.remove(medico);
        gerEntidade.getTransaction().commit();
        gerEntidade.close();
    }

    
    public List<Medico> listaMedico() {
        List<Medico> medico;
        EntityManager gerEntidade;
        Query consulta;
        String consultaSQL;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        consultaSQL = "select medico from Medico medico";
        consulta = gerEntidade.createQuery(consultaSQL);
        medico = consulta.getResultList();
        gerEntidade.close();
        return medico;
    }

    public List<Medico> pesquisaMedico(String pesquisa) {
        List<Medico> medico;
        EntityManager gerEntidade;
        TypedQuery<Medico> consulta;
        String parSQL;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        parSQL = "%"+pesquisa+"%";
        consulta = gerEntidade.createNamedQuery("MedicoConsultaNome",Medico.class);
        consulta.setParameter("titbusca", parSQL);
        medico = consulta.getResultList();
        gerEntidade.close();
        return medico;
    }

}
