/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ManterMedico;

import java.beans.PropertyChangeListener;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="medico")
@NamedQueries (
        {
            @NamedQuery(name="MedicoConsultaNome",
                    //nao pode colocar parametro entre os dois pontos e 
                    query="SELECT m FROM Medico m WHERE m.nome LIKE :titbusca"),
                 
        })
public class Medico implements Serializable{

   
    @Id
    private int codigo;
    private String cpf;
    private String rg;
    private String nome;
    private String cidade;
    private String endereco;
    private String uf;
    private String nomeuser;
    private String senha;
    private String email;

    private String  datanasc;
    
   /* @Temporal(javax.persistence.TemporalType.DATE)
    private Date inicio;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date termino;*/
    private String telefone;
    private String crm;
    private String especialidade;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
      
        this.cpf = cpf;
   
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
       
        this.rg = rg;
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
       
        this.nome = nome;
       
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
       
        this.cidade = cidade;
        
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
       
        this.endereco = endereco;
       
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        String oldUf = this.uf;
        this.uf = uf;
        
    }

    public String getNomeuser() {
        return nomeuser;
    }

    public void setNomeuser(String nomeuser) {
       
        this.nomeuser = nomeuser;
      
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
    
        this.senha = senha;
       
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
      
        this.email = email;
        
    }

    public String getDatanasc() {
        return datanasc;
    }

    public void setDatanasc(String datanasc) {
        this.datanasc = datanasc;
    }


    

  /*  public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
      
        this.inicio = inicio;
       
    }

    public Date getTermino() {
        return termino;
    }

    public void setTermino(Date termino) {
      
        this.termino = termino;
      
    }*/

    

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
       
        this.telefone = telefone;
       
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
      
        this.crm = crm;
  
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
      
        this.especialidade = especialidade;
   
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Medico other = (Medico) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return true;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
     
        this.codigo = codigo;
       
    }


    
    
    
}
