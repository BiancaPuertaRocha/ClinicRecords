
package ManterSetor;

import Utilidades.GerenciamentoEntidades;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class ControleSetor {

    EntityManagerFactory fabrica;

    public ControleSetor() {

    }

    public void adicionaSetor(Setor novoSetor) {
        EntityManager gerEntidade;
       
        gerEntidade = GerenciamentoEntidades.criarGerente();

        gerEntidade.getTransaction().begin();

        gerEntidade.persist(novoSetor);

        gerEntidade.getTransaction().commit();

        gerEntidade.close();
    }

    public void alteraSetor(Setor setor) {
        EntityManager gerEntidade;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        gerEntidade.getTransaction().begin();
        gerEntidade.merge(setor);
        gerEntidade.getTransaction().commit();
        gerEntidade.close();
    }

    public void excluiSetor(Setor setor) {
        EntityManager gerEntidade;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        gerEntidade.getTransaction().begin();
        setor = gerEntidade.find(Setor.class, setor.getCodigo());
        gerEntidade.remove(setor);
        gerEntidade.getTransaction().commit();
        gerEntidade.close();
    }

    
    public List<Setor> listaSetor() {
        List<Setor> setor;
        EntityManager gerEntidade;
        Query consulta;
        String consultaSQL;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        consultaSQL = "select setor from Setor setor";
        consulta = gerEntidade.createQuery(consultaSQL);
        setor = consulta.getResultList();
        gerEntidade.close();
        return setor;
    }

    public List<Setor> pesquisaSetor(String pesquisa) {
        List<Setor> setor;
        EntityManager gerEntidade;
        TypedQuery<Setor> consulta;
        String parSQL;
        gerEntidade = GerenciamentoEntidades.criarGerente();
        parSQL = "%"+pesquisa+"%";
        consulta = gerEntidade.createNamedQuery("SetorConsultaDesc",Setor.class);
        consulta.setParameter("titbusca", parSQL);
        setor = consulta.getResultList();
        gerEntidade.close();
        return setor;
    }

}