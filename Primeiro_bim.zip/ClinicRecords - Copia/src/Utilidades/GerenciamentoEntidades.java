package Utilidades;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * Classe estatica (mesmo para todos) para não ficar crianco um toda vez que
 * você precisr usar no caso, a fabrica de entidades.
 */
public class GerenciamentoEntidades {

    //cria identificador
    private static EntityManagerFactory fabEntidades;

    public GerenciamentoEntidades() {

    }
    // retorna a fabrica de entidades

    public static EntityManagerFactory getFabEntidades() {
        //verifica se a fabrica não foi criada
        if (fabEntidades == null) {
            fabEntidades = Persistence.createEntityManagerFactory("ClinicRecordsPU");
        }
        return fabEntidades;
    }

    public static EntityManager criarGerente() {
        if (fabEntidades == null) {
            fabEntidades = Persistence.createEntityManagerFactory("ClinicRecordsPU");
        }
        return fabEntidades.createEntityManager();
    }

}
